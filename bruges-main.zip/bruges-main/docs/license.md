# License

```{include} ../LICENSE.txt
```