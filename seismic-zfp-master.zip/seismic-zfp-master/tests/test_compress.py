import os
import numpy as np
from seismic_zfp.conversion import SeismicFileConverter, SegyConverter, SgzConverter, NumpyConverter, StreamConverter
from seismic_zfp.sgzconstants import HEADER_DETECTION_CODES
from seismic_zfp.read import SgzReader
from seismic_zfp.headers import HeaderwordInfo
import seismic_zfp
import segyio
import pytest
from seismic_zfp.utils import generate_fake_seismic
from seismic_zfp.seismicfile import SeismicFile
import warnings

import mock
import psutil

try:
    with warnings.catch_warnings():
        # pyzgy will warn us that sdglue is not available. This is expected, and safe for our purposes.
        warnings.filterwarnings("ignore", message="seismic store access is not available: No module named 'sdglue'")
        import pyzgy
        from seismic_zfp.conversion import ZgyConverter
except ImportError:
    pyzgy = None

try:
    import pyvds
    from seismic_zfp.conversion import VdsConverter
except ImportError:
    pyvds = None


SGY_FILE_IEEE = 'test_data/small-ieee.sgy'
SGY_FILE_US = 'test_data/small_us.sgy'
SGY_FILE = 'test_data/small.sgy'
SGY_FILE_2D = 'test_data/small-2d.sgy'
SGY_FILE_2D_CROSSLINE_3D = 'test_data/small-2d-CROSSLINE_3D.sgy'
SGY_FILE_2D_INLINE_3D = 'test_data/small-2d-INLINE_3D.sgy'
SGY_FILE_REVERSE_IL = 'test_data/small_reverse_il.sgy'
SGY_FILE_NEGATIVE_IL_XL = 'test_data/small_negative_il_xl.sgy'
SGY_FILE_NEGATIVE_SAMPLES = 'test_data/small-negative-samples.sgy'
SGY_FILE_TRACEHEADER_SAMPLERATE = 'test_data/small-traceheader-samplerate.sgy'
SGY_FILE_DUPLICATE_TRACEHEADERS = 'test_data/small-duplicate-traceheaders.sgy'
SGY_FILE_512 = 'test_data/tracecount512.sgy'
SGZ_FILE = 'test_data/small_8bit.sgz'
SGZ_FILE_2 = 'test_data/small_2bit.sgz'

SGY_FILE_IRREG = 'test_data/small-irregular.sgy'
SGZ_FILE_IRREG = 'test_data/small-irregular.sgz'
SGY_FILE_IRREG_DEC = 'test_data/small-irreg-dec.sgy'

ZGY_FILE_32 = 'test_data/zgy/small-32bit.zgy'
ZGY_FILE_16 = 'test_data/zgy/small-16bit.zgy'
ZGY_FILE_8 = 'test_data/zgy/small-8bit.zgy'
ZGY_FILE_FLOAT_SR = 'test_data/zgy/small-float-samplerate.zgy'

VDS_FILE = 'test_data/vds/small.vds'

SGY_FILE_32 = 'test_data/zgy/small-32bit.sgy'
SGY_FILE_16 = 'test_data/zgy/small-16bit.sgy'
SGY_FILE_8 = 'test_data/zgy/small-8bit.sgy'


def test_headerword_info_roundtrip():
    with seismic_zfp.open(SGZ_FILE) as sgzfile:
        buffer = sgzfile.hw_info.to_buffer()
    hw_info = HeaderwordInfo(25, buffer=buffer)
    assert hw_info.to_buffer() == buffer


def test_headerword_info_errors():
    with pytest.raises(RuntimeError):
        HeaderwordInfo(25)

    with pytest.raises(RuntimeError):
        with SeismicFile.open(SGZ_FILE) as sgzfile:
            HeaderwordInfo(25, seismicfile=sgzfile)


def test_compress_sgz_file_errors(tmp_path):
    with pytest.raises(RuntimeError):
        out_sgz = os.path.join(str(tmp_path), 'test_compress_sgz_file_errors.sgz')
        with SeismicFileConverter(SGZ_FILE) as converter:
            converter.run(out_sgz, bits_per_voxel=8)


@mock.patch('psutil.virtual_memory')
def test_compress_oom_error(mocked_virtual_memory, tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'oom.sgz')
    psutil.virtual_memory().total = 1024
    with pytest.raises(RuntimeError):
        with SeismicFileConverter(SGY_FILE) as converter:
            converter.run(out_sgz)


def compress_and_compare_detecting_filetypes(input_file, reader, tmp_path):
    out_sgz = os.path.join(str(tmp_path),
                           f'test_detecting_filetype_{os.path.splitext(os.path.basename(input_file))[0]}_.sgz')
    with SeismicFileConverter(input_file) as converter:
        converter.run(out_sgz, bits_per_voxel=8)

    with seismic_zfp.open(out_sgz) as sgzfile:
        sgz_data = sgzfile.read_volume()

    assert np.allclose(sgz_data, reader.tools.cube(input_file), rtol=1e-6)


@pytest.mark.skipif(pyvds is None or pyzgy is None, reason="Requires pyvds and pyzgy")
def test_compress_detecting_filetypes(tmp_path):
    compress_and_compare_detecting_filetypes(SGY_FILE, segyio, tmp_path)
    compress_and_compare_detecting_filetypes(ZGY_FILE_32, pyzgy, tmp_path)
    compress_and_compare_detecting_filetypes(VDS_FILE, pyvds, tmp_path)


def compress_and_compare_vds(vds_file, tmp_path, bits_per_voxel, rtol, blockshape):
    out_filename = f'test_{os.path.splitext(os.path.basename(vds_file))[0]}_{bits_per_voxel}_.sgz'
    out_filepath = os.path.join(str(tmp_path), out_filename)

    with VdsConverter(vds_file) as converter:
        converter.run(out_filepath, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with seismic_zfp.open(out_filepath) as sgzfile:
        with pyvds.open(vds_file) as vdsfile:
            ref_ilines = vdsfile.ilines
            ref_samples = vdsfile.samples

            sgz_data = sgzfile.read_volume()
            sgz_ilines = sgzfile.ilines
            sgz_samples = sgzfile.zslices
            assert sgzfile.structured

            for trace_number in range(25):
                sgz_header = sgzfile.header[trace_number]
                vds_header = vdsfile.header[trace_number]
                assert sgz_header == vds_header

    assert np.allclose(sgz_data, pyvds.tools.cube(vds_file), rtol=rtol)
    assert all([a == b for a, b in zip(sgz_ilines, ref_ilines)])
    assert all(ref_samples == sgz_samples)
    assert 30 == SgzReader(out_filepath).get_file_source_code()


@pytest.mark.skipif(pyvds is None, reason="Requires pyvds")
def test_compress_vds(tmp_path):
    compress_and_compare_vds(VDS_FILE, tmp_path, 8, 1e-6, blockshape=(4, 4, -1))
    compress_and_compare_vds(VDS_FILE, tmp_path, 2, 1e-4, blockshape=(64, 64, 4))


def compress_and_compare_zgy(zgy_file, sgy_file, tmp_path, bits_per_voxel, rtol, blockshape):
    out_filename = f'test_{os.path.splitext(os.path.basename(zgy_file))[0]}_{bits_per_voxel}_.sgz'
    out_filepath = os.path.join(str(tmp_path), out_filename)

    with ZgyConverter(zgy_file) as converter:
        converter.run(out_filepath, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with seismic_zfp.open(out_filepath) as sgzfile:
        with pyzgy.open(zgy_file) as zgyfile:
            ref_ilines = zgyfile.ilines
            ref_samples = zgyfile.samples

            sgz_data = sgzfile.read_volume()
            sgz_ilines = sgzfile.ilines
            sgz_samples = sgzfile.zslices
            assert sgzfile.structured

            for trace_number in range(25):
                sgz_header = sgzfile.header[trace_number]
                zgy_header = zgyfile.header[trace_number]
                for header_pos in [71, 115, 117, 181, 185, 189, 193]:
                    assert sgz_header[header_pos] == zgy_header[header_pos]

    assert np.allclose(sgz_data, segyio.tools.cube(sgy_file), rtol=rtol)
    assert all([a == b for a, b in zip(sgz_ilines, ref_ilines)])
    assert all(ref_samples == sgz_samples)
    assert 10 == SgzReader(out_filepath).get_file_source_code()


@pytest.mark.skipif(pyzgy is None, reason="Requires pyzgy")
def test_compress_zgy(tmp_path):
    compress_and_compare_zgy(ZGY_FILE_8, SGY_FILE_8, tmp_path, 16, 1e-4, blockshape=(4, 4, -1))
    compress_and_compare_zgy(ZGY_FILE_16, SGY_FILE_16, tmp_path, 16, 1e-4, blockshape=(4, 4, -1))
    compress_and_compare_zgy(ZGY_FILE_32, SGY_FILE_32, tmp_path, 16, 1e-5, blockshape=(4, 4, -1))
    compress_and_compare_zgy(ZGY_FILE_32, SGY_FILE_32, tmp_path, 2, 1e-4, blockshape=(64, 64, 4))


@pytest.mark.skipif(pyvds is None, reason="Requires pyvds")
def test_compress_vds(tmp_path):
    compress_and_compare_vds(VDS_FILE, tmp_path, 8, 1e-6, blockshape=(4, 4, -1))
    compress_and_compare_vds(VDS_FILE, tmp_path, 2, 1e-4, blockshape=(64, 64, 4))


def compress_and_compare_zgy_float_sr(zgy_file, tmp_path, bits_per_voxel, blockshape):
    out_filename = f'test_{os.path.splitext(os.path.basename(zgy_file))[0]}_{bits_per_voxel}_.sgz'
    out_filepath = os.path.join(str(tmp_path), out_filename)

    with ZgyConverter(zgy_file) as converter:
        converter.run(out_filepath, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with seismic_zfp.open(out_filepath) as sgzfile:
        with pyzgy.open(zgy_file) as zgyfile:
            ref_ilines = zgyfile.ilines
            ref_samples = np.arange(2558.034423828125, 3501.77894402, 4.309335708618164)

            sgz_ilines = sgzfile.ilines
            sgz_samples = sgzfile.zslices
            assert sgzfile.structured

    assert all([a == b for a, b in zip(sgz_ilines, ref_ilines)])
    assert all(ref_samples == sgz_samples)
    assert 10 == SgzReader(out_filepath).get_file_source_code()


@pytest.mark.skipif(pyzgy is None, reason="Requires pyzgy")
def test_compress_zgy_float_sr(tmp_path):
    compress_and_compare_zgy_float_sr(ZGY_FILE_FLOAT_SR, tmp_path, 2, blockshape=(64, 64, 4))


def compress_and_compare_axes(sgy_file, unit, tmp_path):
    out_sgz = os.path.join(str(tmp_path), f'small_test_axes_{unit}.sgz')

    with SegyConverter(sgy_file) as converter:
        converter.run(out_sgz)

    with segyio.open(sgy_file) as f:
        with SgzReader(out_sgz) as reader:
            assert np.all(reader.ilines == f.ilines)
            assert np.all(reader.xlines == f.xlines)
            assert np.all(reader.zslices == f.samples)
            assert reader.tracecount == f.tracecount
            assert reader.structured


def test_compress_axes(tmp_path):
    compress_and_compare_axes(SGY_FILE, "milliseconds", tmp_path)
    compress_and_compare_axes(SGY_FILE_REVERSE_IL, "reversed_il", tmp_path)
    compress_and_compare_axes(SGY_FILE_NEGATIVE_IL_XL, "negative_il_xl", tmp_path)
    compress_and_compare_axes(SGY_FILE_US, "microseconds", tmp_path)
    compress_and_compare_axes(SGY_FILE_NEGATIVE_SAMPLES, "milliseconds", tmp_path)
    compress_and_compare_axes(SGY_FILE_TRACEHEADER_SAMPLERATE, "microseconds", tmp_path)


def compress_and_compare_data(sgy_file, tmp_path, bits_per_voxel, rtol, blockshape=(4, 4, -1)):
    for reduce_iops in [True, False]:
        out_sgz = os.path.join(str(tmp_path), f'small_test_data_{bits_per_voxel}_{reduce_iops}_.sgz')

        with SegyConverter(sgy_file) as converter:
            converter.run(out_sgz, bits_per_voxel=bits_per_voxel, blockshape=blockshape, reduce_iops=reduce_iops)

        with SgzReader(out_sgz) as reader:
            sgz_data = reader.read_volume()
            assert reader.structured

        assert np.allclose(sgz_data, segyio.tools.cube(sgy_file), rtol=rtol)


def test_compress_data(tmp_path):
    compress_and_compare_data(SGY_FILE_IEEE, tmp_path, 8, 1e-8)
    compress_and_compare_data(SGY_FILE, tmp_path, 8, 1e-10)
    compress_and_compare_data(SGY_FILE, tmp_path, 8.0, 1e-10)
    compress_and_compare_data(SGY_FILE, tmp_path, "8.0", 1e-10)
    compress_and_compare_data(SGY_FILE, tmp_path, "8", 1e-10)

    compress_and_compare_data(SGY_FILE, tmp_path, -2, 1e-1)
    compress_and_compare_data(SGY_FILE, tmp_path, 0.5, 1e-1)
    compress_and_compare_data(SGY_FILE, tmp_path, "0.5", 1e-1)

    compress_and_compare_data(SGY_FILE, tmp_path, 2, 1e-4, blockshape=(64, 64, 4))
    compress_and_compare_data(SGY_FILE, tmp_path, 8, 1e-10, blockshape=(16, 16, 16))


def compress_and_compare_2d_data(sgy_file, tmp_path, bits_per_voxel, rtol, blockshape=(1, 16, -1)):
    out_sgz = os.path.join(str(tmp_path), 'small-2d_test_data.sgz')

    with SegyConverter(sgy_file) as converter:
        converter.run(out_sgz, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with segyio.open(sgy_file, ignore_geometry=True) as f_sgy:
        with seismic_zfp.open(out_sgz) as f_sgz:
            for sgz_trace, sgy_trace in zip(f_sgz.trace, f_sgy.trace):
                assert np.allclose(sgz_trace, sgy_trace, rtol=rtol)


def test_compress_2d_data(tmp_path):
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 4, 2.e-2)
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 8, 1.e-3)
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 16, 1.e-5)

    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 4, 2.e-2, blockshape=(1, 16, 512))
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 16, 1.e-5, blockshape=(1, 16, 128))
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 16, 1.e-5, blockshape=(1, 4, 512))
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 16, 1.e-5, blockshape=(1, 128, 16))
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 16, 1.e-5, blockshape=(1, 512, 4))
    compress_and_compare_2d_data(SGY_FILE_2D, tmp_path, 8, 1.e-3, blockshape=(1, 64, 64))

    compress_and_compare_2d_data(SGY_FILE_2D_CROSSLINE_3D, tmp_path, 16, 1.e-5)
    compress_and_compare_2d_data(SGY_FILE_2D_INLINE_3D, tmp_path, 16, 1.e-5)


def compress_compare_headers(sgy_file, tmp_path, strict=True):
    for detection_method in ['heuristic', 'thorough', 'exhaustive', 'strip']:
        out_sgz = os.path.join(str(tmp_path), f'{os.path.basename(sgy_file)}_test_headers-{detection_method}.sgz')

        with SegyConverter(sgy_file) as converter:
            converter.run(out_sgz, bits_per_voxel=8, header_detection=detection_method)

        with seismic_zfp.open(out_sgz) as sgz_file:
            with segyio.open(sgy_file, strict=strict) as f:
                for sgz_header, sgy_header in zip(sgz_file.header, f.header):
                    if detection_method == 'strip':
                        assert all([0 == value for value in sgz_header.values()])
                    else:
                        assert sgz_header == sgy_header
                    assert sgz_file.get_header_detection_method_code() == HEADER_DETECTION_CODES[detection_method]
                    assert 0 == sgz_file.get_file_source_code()


def test_compress_headers(tmp_path):
    compress_compare_headers(SGY_FILE, tmp_path)
    compress_compare_headers(SGY_FILE_DUPLICATE_TRACEHEADERS, tmp_path)
    compress_compare_headers(SGY_FILE_2D, tmp_path, strict=False)
    compress_compare_headers(SGY_FILE_2D_CROSSLINE_3D, tmp_path, strict=False)
    compress_compare_headers(SGY_FILE_2D_INLINE_3D, tmp_path, strict=False)
    compress_compare_headers(SGY_FILE_512, tmp_path)


def test_compress_headers_errors(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test_headers_errors.sgz')
    with pytest.raises(NotImplementedError):
        with SegyConverter(SGY_FILE) as converter:
            converter.run(out_sgz, bits_per_voxel=8, header_detection='fake-method')


def test_compress_source_data_hash(tmp_path):
    out_sgzs = [os.path.join(str(tmp_path), f'test_hash{bits_per_voxel}.sgz') for bits_per_voxel in [8, 4, 2, 1]]

    for out_sgz, bits_per_voxel in zip(out_sgzs, [8, 4, 2, 1]):
        with SegyConverter(SGY_FILE) as converter:
            converter.run(out_sgz, bits_per_voxel=bits_per_voxel)

    hashes = [SgzReader(out_sgz).get_source_data_hash() for out_sgz in out_sgzs]
    assert all(hash == hashes[0] for hash in hashes)


def test_get_output_size_default(tmp_path):
    """Test get_output_size with default parameters."""
    out_sgz = os.path.join(str(tmp_path), 'test_size_default.sgz')

    with SegyConverter(SGY_FILE) as converter:
        estimated_size = converter.get_output_size(bits_per_voxel=4)
        converter.run(out_sgz, bits_per_voxel=4)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size


@pytest.mark.parametrize("bits_per_voxel", [1, 2, 4, 8])
def test_get_output_size_varying_bitrate(tmp_path, bits_per_voxel):
    """Test get_output_size with different bits-per-voxel values."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_bpv{bits_per_voxel}.sgz')

    with SegyConverter(SGY_FILE) as converter:
        estimated_size = converter.get_output_size(bits_per_voxel=bits_per_voxel)
        converter.run(out_sgz, bits_per_voxel=bits_per_voxel)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"Size mismatch for bits_per_voxel={bits_per_voxel}: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.parametrize("blockshape,bits_per_voxel", [((4, 4, -1), 4), ((64, 64, 4), 2)])
def test_get_output_size_varying_blockshape(tmp_path, blockshape, bits_per_voxel):
    """Test get_output_size with different blockshape values."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_blockshape_{blockshape[0]}.sgz')

    with SegyConverter(SGY_FILE) as converter:
        estimated_size = converter.get_output_size(blockshape=blockshape, bits_per_voxel=bits_per_voxel)
        converter.run(out_sgz, blockshape=blockshape, bits_per_voxel=bits_per_voxel)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"Size mismatch for blockshape={blockshape}, bits_per_voxel={bits_per_voxel}: estimated {estimated_size}, actual {actual_size}"


def test_get_output_size_irreg(tmp_path):
    """Test get_output_size with different blockshape values."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_blockshape_.sgz')

    with SegyConverter(SGY_FILE_IRREG) as converter:
        estimated_size = converter.get_output_size(bits_per_voxel=4)
        converter.run(out_sgz, bits_per_voxel=4)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"Size mismatch: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.parametrize("header_detection", ['heuristic', 'exhaustive', 'strip'])
def test_get_output_size_varying_header_detection(tmp_path, header_detection):
    """Test get_output_size with different header detection modes."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_hdr_{header_detection}.sgz')

    with SegyConverter(SGY_FILE) as converter:
        estimated_size = converter.get_output_size(header_detection=header_detection)
        converter.run(out_sgz, header_detection=header_detection)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"Size mismatch for header_detection={header_detection}: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.skipif(pyzgy is None, reason="Requires pyzgy")
def test_get_output_size_zgy_varying_bitrate(tmp_path):
    """Test get_output_size with ZgyConverter for different bits-per-voxel values."""
    for bits_per_voxel in [1, 2, 4]:
        out_sgz = os.path.join(str(tmp_path), f'test_size_zgy_bpv{bits_per_voxel}.sgz')

        with ZgyConverter(ZGY_FILE_8) as converter:
            estimated_size = converter.get_output_size(bits_per_voxel=bits_per_voxel)
            converter.run(out_sgz, bits_per_voxel=bits_per_voxel)

        actual_size = os.path.getsize(out_sgz)
        assert estimated_size == actual_size, \
            f"ZGY: Size mismatch for bits_per_voxel={bits_per_voxel}: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.skipif(pyzgy is None, reason="Requires pyzgy")
@pytest.mark.parametrize("blockshape,bits_per_voxel", [((4, 4, -1), 4), ((64, 64, 4), 2)])
def test_get_output_size_zgy_varying_blockshape(tmp_path, blockshape, bits_per_voxel):
    """Test get_output_size with ZgyConverter for different blockshape values."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_zgy_blockshape_{blockshape[0]}.sgz')

    with ZgyConverter(ZGY_FILE_8) as converter:
        estimated_size = converter.get_output_size(blockshape=blockshape, bits_per_voxel=bits_per_voxel)
        converter.run(out_sgz, blockshape=blockshape, bits_per_voxel=bits_per_voxel)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"ZGY: Size mismatch for blockshape={blockshape}, bits_per_voxel={bits_per_voxel}: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.skipif(pyvds is None, reason="Requires pyvds")
def test_get_output_size_vds_varying_bitrate(tmp_path):
    """Test get_output_size with VdsConverter for different bits-per-voxel values."""
    for bits_per_voxel in [1, 2, 4]:
        out_sgz = os.path.join(str(tmp_path), f'test_size_vds_bpv{bits_per_voxel}.sgz')

        with VdsConverter(VDS_FILE) as converter:
            estimated_size = converter.get_output_size(bits_per_voxel=bits_per_voxel)
            converter.run(out_sgz, bits_per_voxel=bits_per_voxel)

        actual_size = os.path.getsize(out_sgz)
        assert estimated_size == actual_size, \
            f"VDS: Size mismatch for bits_per_voxel={bits_per_voxel}: estimated {estimated_size}, actual {actual_size}"


@pytest.mark.skipif(pyvds is None, reason="Requires pyvds")
@pytest.mark.parametrize("header_detection", ['heuristic', 'strip'])
def test_get_output_size_vds_varying_header_detection(tmp_path, header_detection):
    """Test get_output_size with VdsConverter for different header detection modes."""
    out_sgz = os.path.join(str(tmp_path), f'test_size_vds_hdr_{header_detection}.sgz')

    with VdsConverter(VDS_FILE) as converter:
        estimated_size = converter.get_output_size(header_detection=header_detection)
        converter.run(out_sgz, header_detection=header_detection)

    actual_size = os.path.getsize(out_sgz)
    assert estimated_size == actual_size, \
        f"VDS: Size mismatch for header_detection={header_detection}: estimated {estimated_size}, actual {actual_size}"


def test_compress_crop(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test_data.sgz')

    with SegyConverter(SGY_FILE, min_il=1, max_il=4, min_xl=1, max_xl=3) as converter:
        converter.run(out_sgz, bits_per_voxel=16)

    with SgzReader(out_sgz) as reader:
        sgz_data = reader.read_volume()
        assert reader.structured
        with segyio.open(SGY_FILE) as segyfile:
            assert np.array_equal(reader.ilines, segyfile.ilines[1:4])
            assert np.array_equal(reader.xlines, segyfile.xlines[1:3])
            for i in range(reader.tracecount):
                assert reader.gen_trace_header(i)[189] == reader.ilines[i // 2]
                assert reader.gen_trace_header(i)[193] == reader.xlines[i % 2]

    assert np.allclose(sgz_data, segyio.tools.cube(SGY_FILE)[1:4, 1:3, :], rtol=1e-8)


@pytest.mark.parametrize("crop, expected", [
    # Ordinal 0 is a valid crop bound, not "unspecified"
    (dict(min_il=0, max_il=2, min_xl=0, max_xl=3), (slice(0, 2), slice(0, 3))),
    # Unspecified bounds default to the full extent of that axis
    (dict(max_il=3), (slice(0, 3), slice(None))),
    (dict(min_xl=2), (slice(None), slice(2, None))),
])
def test_compress_crop_zero_and_partial_bounds(tmp_path, crop, expected):
    out_sgz = os.path.join(str(tmp_path), 'small_crop.sgz')
    with SegyConverter(SGY_FILE, **crop) as converter:
        converter.run(out_sgz, bits_per_voxel=16)
    with segyio.open(SGY_FILE) as segyfile, SgzReader(out_sgz) as reader:
        assert np.array_equal(reader.ilines, segyfile.ilines[expected[0]])
        assert np.array_equal(reader.xlines, segyfile.xlines[expected[1]])
        assert np.allclose(reader.read_volume(), segyio.tools.cube(SGY_FILE)[expected], rtol=1e-8)


def test_compress_crop_irregular_rejected():
    with pytest.raises(NotImplementedError):
        SegyConverter(SGY_FILE_IRREG, min_il=0, max_il=2)


def test_compress_crop_header_arrays_sized_to_crop(tmp_path):
    # 512 traces: full-size header arrays (2048 bytes) straddle several 512-byte
    # pages, so a crop must size its header arrays to the cropped tracecount
    # for the footer offsets in the SGZ header to be correct.
    out_sgz = os.path.join(str(tmp_path), 'tracecount512_crop.sgz')
    with SegyConverter(SGY_FILE_512, min_il=2, max_il=14, min_xl=3, max_xl=30) as converter:
        estimated_size = converter.get_output_size(bits_per_voxel=8)
        converter.run(out_sgz, bits_per_voxel=8)

    assert os.path.getsize(out_sgz) == estimated_size

    with segyio.open(SGY_FILE_512) as segyfile:
        with SgzReader(out_sgz) as reader:
            assert reader.tracecount == 12 * 27
            assert np.array_equal(reader.ilines, segyfile.ilines[2:14])
            assert np.array_equal(reader.xlines, segyfile.xlines[3:30])
            reader.read_variant_headers()
            for i in range(reader.tracecount):
                segy_trace = (2 + i // 27) * 32 + 3 + i % 27
                assert reader.gen_trace_header(i) == segyfile.header[segy_trace]
            assert np.allclose(reader.read_volume(), segyio.tools.cube(SGY_FILE_512)[2:14, 3:30, :], rtol=1e-6)


def test_compress_unstructured_decimated(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test-irregular_decimated_data.sgz')

    with SegyConverter(SGY_FILE_IRREG_DEC) as converter:
        converter.run(out_sgz, bits_per_voxel=16)

    with SgzReader(out_sgz) as reader:
        sgz_data = reader.read_volume()
        assert not reader.structured

    segy_cube = segyio.tools.cube(SGY_FILE)[::2, ::2, :]
    segy_cube[2, 2, :] = 0
    assert np.allclose(sgz_data, segy_cube, atol=1e-4)


def test_make_header_unstructured_axis_steps():
    from seismic_zfp.conversion_utils import make_header
    from seismic_zfp.utils import InferredGeometry3d, bytes_to_signed_int
    # IL step 2, XL step 1, one trace missing so the geometry is irregular
    traces_ref = {(il, xl): i for i, (il, xl) in enumerate(
        (il, xl) for il in (1, 3, 5) for xl in (20, 21, 22) if (il, xl) != (5, 22))}
    geom = InferredGeometry3d(traces_ref)
    hw_info = HeaderwordInfo(n_traces=9, variant_header_list=[])
    header = make_header(None, None, np.arange(0, 40, 4), 8, hw_info, 4, (4, 4, 512), geom, unstructured=True)
    assert bytes_to_signed_int(header[20:24]) == 20   # min xl
    assert bytes_to_signed_int(header[24:28]) == 1    # min il
    assert bytes_to_signed_int(header[32:36]) == 1    # xl step
    assert bytes_to_signed_int(header[36:40]) == 2    # il step


def test_compress_unstructured_asymmetric_steps(tmp_path):
    # Every other inline of small.sgy with one trace removed: IL step 2, XL step 1
    sgy_dec = os.path.join(str(tmp_path), 'small-il-dec-hole.sgy')
    with segyio.open(SGY_FILE) as src:
        keep = [i for i, h in enumerate(src.header) if h[189] % 2 == 1 and (h[189], h[193]) != (5, 24)]
        spec = segyio.spec()
        spec.format, spec.samples, spec.tracecount = src.format, src.samples, len(keep)
        with segyio.create(sgy_dec, spec) as dst:
            dst.text[0], dst.bin = src.text[0], src.bin
            for n, i in enumerate(keep):
                dst.header[n], dst.trace[n] = src.header[i], src.trace[i]

    out_sgz = os.path.join(str(tmp_path), 'small-il-dec-hole.sgz')
    with SegyConverter(sgy_dec) as converter:
        converter.run(out_sgz, bits_per_voxel=16)

    with SgzReader(out_sgz) as reader:
        assert not reader.structured
        assert np.array_equal(reader.ilines, [1, 3, 5])
        assert np.array_equal(reader.xlines, [20, 21, 22, 23, 24])
        segy_cube = segyio.tools.cube(SGY_FILE)[::2, :, :]
        segy_cube[2, 4, :] = 0
        assert np.allclose(reader.read_volume(), segy_cube, atol=1e-4)


def test_compress_unstructured_headers(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test-irregular_headers.sgz')

    with SegyConverter(SGY_FILE_IRREG) as converter:
        converter.run(out_sgz, bits_per_voxel=8)

    with SgzReader(out_sgz) as reader:
        reader.read_variant_headers()
        il_header_sgz = reader.variant_headers[189]
        xl_header_sgz = reader.variant_headers[193]
        n_traces_sgz = reader.tracecount
        assert not reader.structured

    with SgzReader(out_sgz) as reader:
        reader.read_variant_headers(include_padding=True)
        il_header_sgz_padded = reader.variant_headers[189]
        xl_header_sgz_padded = reader.variant_headers[193]

    with segyio.open(SGY_FILE_IRREG, strict=False) as f:
        il_header_sgy = np.array([h[189] for h in f.header])
        xl_header_sgy = np.array([h[193] for h in f.header])
        n_traces_sgy = f.tracecount
        with seismic_zfp.open(out_sgz) as f_sgz:
            for sgz_trace, sgy_trace in zip(f_sgz.trace, f.trace):
                assert np.allclose(sgz_trace, sgy_trace, rtol=1e-2)

    with segyio.open(SGY_FILE, strict=False) as f:
        il_header_sgy_padded = np.array([h[189] for h in f.header])
        xl_header_sgy_padded = np.array([h[193] for h in f.header])
    il_header_sgy_padded[-1] = 0
    xl_header_sgy_padded[-1] = 0

    assert n_traces_sgz == n_traces_sgy
    assert np.array_equal(il_header_sgz, il_header_sgy)
    assert np.array_equal(xl_header_sgz, xl_header_sgy)
    assert np.array_equal(il_header_sgz_padded, il_header_sgy_padded)
    assert np.array_equal(xl_header_sgz_padded, xl_header_sgy_padded)


def test_compress_unstructured_data(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test-irregular_data.sgz')

    with SegyConverter(SGY_FILE_IRREG) as converter:
        converter.run(out_sgz, bits_per_voxel=8)

    with SgzReader(out_sgz) as reader:
        sgz_data = reader.read_volume()
        reader.read_variant_headers()
        assert not reader.structured

    with SgzReader(out_sgz) as reader:
        reader.read_variant_headers(include_padding=True)

    with segyio.open(SGY_FILE_IRREG, strict=False) as f:
        with seismic_zfp.open(out_sgz) as f_sgz:
            for sgz_trace, sgy_trace in zip(f_sgz.trace, f.trace):
                assert np.allclose(sgz_trace, sgy_trace, rtol=1e-2)

    segy_cube = segyio.tools.cube(SGY_FILE)
    segy_cube[4, 4, :] = 0
    assert np.allclose(sgz_data, segy_cube, rtol=1e-2)


def test_compress_unstructured_reduce_iops(tmp_path):
    with pytest.warns(UserWarning):
        out_sgz = os.path.join(str(tmp_path), 'small_test_data_reduce-iops.sgz')
        with SegyConverter(SGY_FILE_IRREG) as converter:
            converter.run(out_sgz, reduce_iops=True)


def test_compresss_non_existent_file(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'non-existent-file.sgz')
    with pytest.raises(FileNotFoundError):
        with SegyConverter('./non-existent-file.sgy') as converter:
            converter.run(out_sgz)
    with pytest.raises(FileNotFoundError):
        with SeismicFileConverter('./non-existent-file') as converter:
            converter.run(out_sgz)


def test_convert_to_adv_from_compressed(tmp_path):
    out_sgz = os.path.join(str(tmp_path), 'small_test_data_convert-adv.sgz')

    with SgzConverter(SGZ_FILE_2) as converter:
        converter.convert_to_adv_sgz(out_sgz)

    with SgzReader(SGZ_FILE_2) as reader:
        sgz_data = reader.read_volume()

    with SgzReader(out_sgz) as reader:
        sgz_adv_data = reader.read_volume()

    assert np.array_equal(sgz_data, sgz_adv_data)


def compress_numpy_and_compare_data(n_samples, min_iline, n_ilines, min_xline, n_xlines,
                                    tmp_path, bits_per_voxel, rtol, blockshape=(4, 4, -1)):

    out_sgz = os.path.join(str(tmp_path), 'from-numpy.sgz')
    out_sgz_no_headers = os.path.join(str(tmp_path), 'from-numpy_no_headers.sgz')

    array, ilines, xlines, samples = generate_fake_seismic(n_ilines, n_xlines, n_samples,
                                                           min_iline=min_iline, min_xline=min_xline)

    trace_headers = {segyio.tracefield.TraceField.INLINE_3D:
                     np.broadcast_to(np.expand_dims(ilines, axis=1), (n_ilines, n_xlines)),
                     segyio.tracefield.TraceField.CROSSLINE_3D:
                     np.broadcast_to(xlines, (n_ilines, n_xlines))}

    with NumpyConverter(array, ilines=ilines, xlines=xlines, samples=samples, trace_headers=trace_headers) as converter:
        converter.run(out_sgz, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with SgzReader(out_sgz) as reader:
        # print(np.max(np.abs(reader.read_volume()-array)/np.abs(array)))
        assert np.allclose(reader.ilines, ilines, rtol=rtol)
        assert np.allclose(reader.xlines, xlines, rtol=rtol)
        assert np.allclose(reader.zslices, samples, rtol=rtol)
        assert np.allclose(reader.read_volume(), array, rtol=rtol)
        assert 20 == reader.get_file_source_code()

    with NumpyConverter(array) as converter:
        converter.run(out_sgz_no_headers, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with SgzReader(out_sgz_no_headers) as reader:
        assert np.allclose(reader.ilines, np.arange(array.shape[0]), rtol=rtol)
        assert np.allclose(reader.xlines, np.arange(array.shape[1]), rtol=rtol)
        assert np.allclose(reader.read_volume(), array, rtol=rtol)
        assert 20 == reader.get_file_source_code()


def test_compress_numpy_data(tmp_path):
    compress_numpy_and_compare_data(16, 0, 8, 8, 12, tmp_path, 8, 1e-3)
    compress_numpy_and_compare_data(801, 0, 8, 8, 12, tmp_path, 8, 1e-3)
    compress_numpy_and_compare_data(512, 0, 9, 8, 12, tmp_path, 8, 1e-3)
    compress_numpy_and_compare_data(512, 0, 8, 8, 13, tmp_path, 8, 1e-3)

    compress_numpy_and_compare_data(17, 0, 65, 8, 65, tmp_path, 8, 1e-2, blockshape=(32, 32, 4))
    compress_numpy_and_compare_data(801, 0, 9, 8, 13, tmp_path, 8, 1e-2, blockshape=(16, 16, 16))


def compress_stream_and_compare_data(
    min_sample,
    n_samples,
    min_iline,
    n_ilines,
    min_xline,
    n_xlines,
    tmp_path,
    bits_per_voxel,
    rtol,
    blockshape=(4, 4, -1),
):

    out_sgz_lower_samples_precision = os.path.join(str(tmp_path), "from-stream-lower-samples-precision.sgz")
    out_sgz_higher_samples_precision = os.path.join(str(tmp_path), "from-stream-higher-samples-precision.sgz")
    out_sgz_numpy = os.path.join(str(tmp_path), "from-numpy.sgz")
    out_sgz_no_headers = os.path.join(str(tmp_path), "from-stream_no_headers.sgz")

    array, ilines, xlines, samples = generate_fake_seismic(
        n_ilines, n_xlines, n_samples, min_iline=min_iline, min_xline=min_xline, min_sample=min_sample
    )

    trace_headers = {
        segyio.tracefield.TraceField.INLINE_3D: np.broadcast_to(
            np.expand_dims(ilines, axis=1), (n_ilines, n_xlines)
        ),
        segyio.tracefield.TraceField.CROSSLINE_3D: np.broadcast_to(
            xlines, (n_ilines, n_xlines)
        ),
    }
    lower_samples_precision = samples.astype(int)

    with StreamConverter(
        out_sgz_lower_samples_precision,
        ilines=ilines,
        xlines=xlines,
        samples=samples,
        bits_per_voxel=bits_per_voxel,
        blockshape=blockshape,
        trace_headers=trace_headers,
    ) as converter:
        for i in range(0, array.shape[0], blockshape[0]):
            end = min(i + blockshape[0], array.shape[0])
            chunk = array[i:end, :, :]
            converter.write(chunk)
    with SgzReader(out_sgz_lower_samples_precision) as reader:
        assert np.allclose(reader.ilines, ilines, rtol=rtol)
        assert np.allclose(reader.xlines, xlines, rtol=rtol)
        assert np.allclose(reader.zslices, lower_samples_precision, rtol=rtol)
        assert np.allclose(reader.read_volume(), array, rtol=rtol)
        assert 20 == reader.get_file_source_code()

    with StreamConverter(
        out_sgz_higher_samples_precision,
        ilines=ilines,
        xlines=xlines,
        samples=samples,
        bits_per_voxel=bits_per_voxel,
        blockshape=blockshape,
        trace_headers=trace_headers,
        use_higher_samples_precision=True
    ) as converter:
        for i in range(0, array.shape[0], blockshape[0]):
            end = min(i + blockshape[0], array.shape[0])
            chunk = array[i:end, :, :]
            converter.write(chunk)
    with SgzReader(out_sgz_higher_samples_precision) as reader:
        assert np.allclose(reader.ilines, ilines, rtol=rtol)
        assert np.allclose(reader.xlines, xlines, rtol=rtol)
        assert np.allclose(reader.zslices, samples, rtol=rtol)
        assert np.allclose(reader.read_volume(), array, rtol=rtol)
        assert 20 == reader.get_file_source_code()

    with StreamConverter(
        out_sgz_no_headers,
        ilines=ilines,
        xlines=xlines,
        samples=samples,
        bits_per_voxel=bits_per_voxel,
        blockshape=blockshape,
        trace_headers=trace_headers,
        use_higher_samples_precision=False
    ) as converter:
        for i in range(0, array.shape[0], blockshape[0]):
            end = min(i + blockshape[0], array.shape[0])
            chunk = array[i:end, :, :]
            converter.write(chunk)

    with SgzReader(out_sgz_no_headers) as reader:
        assert np.allclose(reader.ilines, ilines, rtol=rtol)
        assert np.allclose(reader.xlines, xlines, rtol=rtol)
        assert np.allclose(reader.zslices, lower_samples_precision, rtol=rtol)
        assert np.allclose(reader.read_volume(), array, rtol=rtol)
        assert 20 == reader.get_file_source_code()
        stream_hash = reader.get_source_data_hash()

    with NumpyConverter(array) as converter:
        converter.run(out_sgz_numpy, bits_per_voxel=bits_per_voxel, blockshape=blockshape)

    with SgzReader(out_sgz_numpy) as reader:
        numpy_hash = reader.get_source_data_hash()

    assert stream_hash == numpy_hash


def test_compress_stream(tmp_path):
    compress_stream_and_compare_data(0, 16, 0, 8, 8, 12, tmp_path, 8, 1e-3)
    compress_stream_and_compare_data(2.5, 16, 0, 8, 8, 12, tmp_path, 8, 1e-3)
    compress_stream_and_compare_data(0, 801, 0, 8, 8, 12, tmp_path, 8, 1e-3)
    compress_stream_and_compare_data(0, 512, 0, 9, 8, 12, tmp_path, 8, 1e-3)
    compress_stream_and_compare_data(0, 512, 0, 8, 8, 13, tmp_path, 8, 1e-3)

    compress_stream_and_compare_data(
        0, 17, 0, 65, 8, 65, tmp_path, 8, 1e-2, blockshape=(32, 32, 4)
    )
    compress_stream_and_compare_data(
        0, 801, 0, 9, 8, 13, tmp_path, 8, 1e-2, blockshape=(16, 16, 16)
    )
