import struct
import time
import datetime
import numpy as np

from .sgzconstants import DISK_BLOCK_BYTES


class WrongDimensionalityError(TypeError):
    pass


class FileOffset(int):
    """Convenience class to enable distinction between default header values and file offsets"""
    def __new__(cls, value):
        return int.__new__(cls, value)


class CubeWithAxes:
    """Utility class to hold 3D numpy array and corresponding axes"""
    def __init__(self, data_array, ilines, xlines, samples):
        self.data_array = data_array
        self.ilines = ilines
        self.xlines = xlines
        self.samples = samples


class Axes:
    """Utility class to hold axes"""
    def __init__(self, ilines, xlines, samples):
        self.ilines = ilines
        self.xlines = xlines
        self.samples = samples


class Geometry3d:
    """Lightweight place to keep track of IL/XL ranges"""
    def __init__(self, min_il, max_il, min_xl, max_xl, il_step=1, xl_step=1):
        self.ilines = range(min_il, max_il, il_step)
        self.xlines = range(min_xl, max_xl, xl_step)


class Geometry4d:
    """Lightweight place to keep track of IL/XL/offset ranges (ordinals) for prestack data"""
    def __init__(self, min_il, max_il, min_xl, max_xl, min_offset, max_offset,
                 il_step=1, xl_step=1, offset_step=1):
        self.ilines = range(min_il, max_il, il_step)
        self.xlines = range(min_xl, max_xl, xl_step)
        self.offsets = range(min_offset, max_offset, offset_step)

    def __repr__(self):
        return (f'IL:[{self.ilines.start},{self.ilines.stop}] -- XL:[{self.xlines.start},{self.xlines.stop}]'
                f' -- OFFSET:[{self.offsets.start},{self.offsets.stop}]')


class InferredGeometry3d(Geometry3d):
    """Subclass used to signify irregular input SEG-Y"""
    def __init__(self, traces_ref):
        self.traces_ref = traces_ref
        il_ids = set([k[0] for k in traces_ref.keys()])
        xl_ids = set([k[1] for k in traces_ref.keys()])
        self.min_il, self.max_il, self.il_step = self.get_range(il_ids)
        self.min_xl, self.max_xl, self.xl_step = self.get_range(xl_ids)
        super().__init__(self.min_il, self.max_il + 1, self.min_xl, self.max_xl + 1,
                         il_step=self.il_step, xl_step=self.xl_step)

    @staticmethod
    def get_range(ids):
        if len(ids)>1:
            step = (max(ids) - min(ids)) // (len(ids) - 1)
        else:
            step = 0 # For 3D cubes with only one inline or crossline
        return min(ids), max(ids), step

    def __repr__(self):
        return f'IL:[{self.min_il},{self.max_il},{self.il_step}] -- XL:[{self.min_xl},{self.max_xl},{self.xl_step}]'


class InferredGeometry4d(Geometry4d):
    """Subclass used to signify irregular prestack input SEG-Y.

    Unlike Geometry4d the ilines/xlines/offsets ranges hold IL/XL/offset *numbers* rather than
    ordinals, spanning the regular grid which encloses every trace in traces_ref.
    """
    def __init__(self, traces_ref):
        self.traces_ref = traces_ref
        il_ids = set([k[0] for k in traces_ref.keys()])
        xl_ids = set([k[1] for k in traces_ref.keys()])
        offset_ids = set([k[2] for k in traces_ref.keys()])
        self.min_il, self.max_il, self.il_step = InferredGeometry3d.get_range(il_ids)
        self.min_xl, self.max_xl, self.xl_step = InferredGeometry3d.get_range(xl_ids)
        self.min_offset, self.max_offset, self.offset_step = InferredGeometry3d.get_range(offset_ids)
        # A step of 0 signifies a single value on that axis, which range() cannot express
        super().__init__(self.min_il, self.max_il + 1, self.min_xl, self.max_xl + 1,
                         self.min_offset, self.max_offset + 1,
                         il_step=self.il_step or 1, xl_step=self.xl_step or 1, offset_step=self.offset_step or 1)
        self._trace_ordinals = None

    def __repr__(self):
        return (f'IL:[{self.min_il},{self.max_il},{self.il_step}] -- XL:[{self.min_xl},{self.max_xl},{self.xl_step}]'
                f' -- OFFSET:[{self.min_offset},{self.max_offset},{self.offset_step}]')

    def _build_trace_ordinals(self):
        """Per-trace (il, xl, offset) grid ordinals, indexed by trace number. -1 marks traces absent from traces_ref."""
        n_traces = max(self.traces_ref.values()) + 1
        ordinals = np.full((3, n_traces), -1, dtype=np.int32)
        steps = (self.il_step or 1, self.xl_step or 1, self.offset_step or 1)
        mins = (self.min_il, self.min_xl, self.min_offset)
        for (il, xl, offset), i in self.traces_ref.items():
            ordinals[0, i] = (il - mins[0]) // steps[0]
            ordinals[1, i] = (xl - mins[1]) // steps[1]
            ordinals[2, i] = (offset - mins[2]) // steps[2]
        self._trace_ordinals = ordinals

    def inline_trace_ids(self, il_id):
        """Trace numbers of every trace on inline ordinal il_id, in file order"""
        if self._trace_ordinals is None:
            self._build_trace_ordinals()
        return np.flatnonzero(self._trace_ordinals[0] == il_id)

    def trace_ordinals(self, trace_ids):
        """(xl_ids, offset_ids) grid ordinals for the given trace numbers"""
        if self._trace_ordinals is None:
            self._build_trace_ordinals()
        return self._trace_ordinals[1, trace_ids], self._trace_ordinals[2, trace_ids]


class Geometry2d:
    """Class used to signify 2D input SEG-Y"""
    def __init__(self, setup_param):
        if isinstance(setup_param, int):
            self.traces = list(range(setup_param))
        elif isinstance(setup_param, np.ndarray):
            self.traces = list(setup_param)


def read_range_file(file, offset, length):
    file.seek(offset)
    return file.read(length)


def read_range_blob(file, offset, length):
    return file.download_blob(offset=offset, length=length).readall()


def generate_fake_seismic(n_ilines, n_xlines, n_samples, min_iline=0, min_xline=0, min_sample=0):
    # Generate an array which looks a *bit* like an impulse-response test...
    ilines, xlines, samples = np.arange(n_ilines), np.arange(n_xlines), np.arange(n_samples)
    array_shape = (n_ilines, n_xlines, n_samples)

    i = np.broadcast_to(np.expand_dims(np.expand_dims((ilines - n_ilines / 2), 1), 2), array_shape).astype(np.float32)
    x = np.broadcast_to(np.expand_dims((xlines - n_xlines / 2), 1), array_shape).astype(np.float32)
    s = np.broadcast_to(samples - n_samples / 4, array_shape).astype(np.float32)
    array = 0.01 + (np.sin(0.1 + np.sqrt(2.0 + (i+0.01) ** 2 + x ** 2 + (s*0.75) ** 2) / 8.0) /
                          (0.1 * np.sqrt(2.0 + (i+0.01) ** 2 + x ** 2 + (s*0.50) ** 2)))
    return array, ilines+min_iline, xlines+min_xline, samples+min_sample


def pad(orig, multiple):
    if orig % multiple == 0:
        return orig
    else:
        return multiple * (orig//multiple + 1)


def describe_axis(coords, name="axis"):
    """e.g. 'inline axis: 193 values from 9985 to 10369, step 2'"""
    if len(coords) == 1:
        return f"{name}: 1 value, {coords[0]}"
    return f"{name}: {len(coords)} values from {coords[0]} to {coords[-1]}, step {coords[1] - coords[0]}"


def coord_to_index(coord, coords, include_stop=False, name="axis"):
    try:
        index = np.where(coords == coord)[0][0]
    except IndexError:
        if include_stop and (coord == coords[-1] + (coords[-1]-coords[-2])):
            return len(coords)
        message = f"Coordinate {coord} not in {describe_axis(coords, name)}"
        if isinstance(coord, (int, np.integer)) and 0 <= coord < len(coords):
            message += " (a coordinate value is expected here, this looks like an ordinal)"
        raise IndexError(message)
    return index


def gen_coord_list(start, step, count):
    return np.arange(start, start + step*count, step)


def bytes_to_double(bytes):
    return struct.unpack("<d", bytes)[0]


def double_to_bytes(value):
    return struct.pack("<d", value)


def np_float_to_bytes(numpy_float):
    # How is this so hard?
    return struct.pack("<I", int(numpy_float.astype(int)))


def np_float_to_bytes_signed(numpy_float):
    return struct.pack("<i", int(numpy_float.astype(int)))


def bytes_to_int(bytes):
    if len(bytes) == 4:
        return struct.unpack('<I', bytes)[0]
    elif len(bytes) == 2:
        return struct.unpack('<H', bytes)[0]


def bytes_to_signed_int(bytes):
    if len(bytes) == 4:
        return struct.unpack('<i', bytes)[0]
    elif len(bytes) == 2:
        return struct.unpack('<h', bytes)[0]


def int_to_bytes(bytes):
    return struct.pack('<I', bytes)


def signed_int_to_bytes(bytes):
    return struct.pack('<i', bytes)


def python_int(int_in):
    if isinstance(int_in, int):
        return int_in
    elif isinstance(int_in, np.integer):
        return int(int_in)
    else:
        raise TypeError("This function requires an integer argument")


def define_blockshape_2d(bits_per_voxel, blockshape):
    assert blockshape[0] == 1
    return define_blockshape_3d(bits_per_voxel, blockshape)


def define_blockshape_3d(bits_per_voxel, blockshape):
    assert len(blockshape) == 3
    return _define_blockshape(bits_per_voxel, blockshape)


def define_blockshape_4d(bits_per_voxel, blockshape):
    assert len(blockshape) == 4
    bits_per_voxel, blockshape = _define_blockshape(bits_per_voxel, blockshape)
    # zfp compresses 4D data in 4x4x4x4 units, so no dimension may be smaller than that
    if any(n < 4 for n in blockshape):
        raise ValueError(f"All 4D blockshape dimensions must be at least 4, got {blockshape}")
    return bits_per_voxel, blockshape


def _define_blockshape(bits_per_voxel, blockshape):
    """Resolve one -1 placeholder among blockshape dimensions and bits_per_voxel such that
    the product fills one disk block exactly. Dimension-agnostic."""
    blockshape = tuple(blockshape)
    if sum([1 for n in blockshape + (bits_per_voxel,) if n == -1]) > 1:
        raise ValueError("Blockshape is underdefined")

    if isinstance(bits_per_voxel, str):
        bits_per_voxel = float(bits_per_voxel)

    bits_per_voxel = 1 / -bits_per_voxel if bits_per_voxel < -1 else bits_per_voxel

    if bits_per_voxel == -1:
        bits_per_voxel = DISK_BLOCK_BYTES * 8 / int(np.prod(blockshape))
    elif -1 in blockshape:
        i = blockshape.index(-1)
        known_voxels = int(np.prod(blockshape[:i] + blockshape[i+1:]))
        resolved = int(DISK_BLOCK_BYTES * 8 // (known_voxels * bits_per_voxel))
        blockshape = blockshape[:i] + (resolved,) + blockshape[i+1:]
    else:
        assert(bits_per_voxel * int(np.prod(blockshape)) == DISK_BLOCK_BYTES * 8)
    return bits_per_voxel, blockshape


def progress_printer(start_time, progress_frac):
    current_time = time.time()
    eta = current_time + ((1. - progress_frac) * (current_time - start_time)) / (progress_frac + 0.0000001)
    st = datetime.datetime.fromtimestamp(eta).strftime('%Y-%m-%d %H:%M:%S')
    print(f"   - {progress_frac * 100:5.1f}% complete. ETA: {st}", end="\r")


def get_correlated_diagonal_length(cd, n_il, n_xl):
    if n_xl > n_il:
        if cd >= 0:
            return n_il - cd
        elif abs(cd) <= n_xl - n_il:
            return n_il
        else:  # cd is negative
            return n_xl + cd
    elif n_xl < n_il:
        if cd <= 0:
            return n_xl + cd
        elif abs(cd) <= n_il - n_xl:
            return n_xl
        else:
            return n_il - cd
    else:  # Equal number of ILs & XLs
        return n_il - abs(cd)


def get_anticorrelated_diagonal_length(ad, n_il, n_xl):
    if ad < min(n_il, n_xl):
        return ad + 1
    elif min(n_il, n_xl) <= ad < max(n_il, n_xl):
        return min(n_il, n_xl)
    else:
        return n_il + n_xl - ad - 1


def get_chunk_cache_size(n_il_chunks, n_xl_chunks):
    """Determine how many chunks are required to hold an arbitrary diagonal in lru cache - must be power of 2"""
    cache_size = 1
    max_chunk_dimension = min(n_il_chunks, n_xl_chunks)
    while cache_size < max_chunk_dimension:
        cache_size = cache_size*2
    return cache_size * 2
