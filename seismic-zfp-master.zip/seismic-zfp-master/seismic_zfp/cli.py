import click
import importlib.metadata

from seismic_zfp.version import SeismicZfpVersion
from seismic_zfp.conversion import SegyConverter, ZgyConverter, SgzConverter

cropping_param_help = (
    "Cropping parameter to apply to input seismic cube. "
    "Refers to IL/XL ordinals rather than numbers."
)
segyconverter_options = [
    click.option(
        "--min-il",
        type=click.INT,
        help=cropping_param_help,
    ),
    click.option(
        "--max-il",
        type=click.INT,
        help=cropping_param_help,
    ),
    click.option(
        "--min-xl",
        type=click.INT,
        help=cropping_param_help,
    ),
    click.option(
        "--max-xl",
        type=click.INT,
        help=cropping_param_help,
    ),
    click.option(
        "--min-offset",
        type=click.INT,
        help="Offset-axis cropping parameter for prestack (4D) SEG-Y. Refers to offset ordinals.",
    ),
    click.option(
        "--max-offset",
        type=click.INT,
        help="Offset-axis cropping parameter for prestack (4D) SEG-Y. Refers to offset ordinals.",
    ),
]
sgz_options = [
    click.option(
        "--bits-per-voxel",
        default=4,
        type=click.INT,
        help=(
            "The number of bits to use for storing each seismic voxel. "
            "Recommended using 4-bit, giving 8:1 compression. "
            "Negative value implies reciprocal: i.e. -2 ==> 1/2 bits per voxel"
        ),
        show_default=True,
    ),
    click.option(
        "--blockshape",
        type=click.Tuple([click.INT] * 3),
        default=None,
        help=(
            "The physical shape of voxels compressed to one disk block. "
            "Can only specify 3 of blockshape (il,xl,z) and bits_per_voxel, "
            "4th is redundant."
            "(4, 4, -1) is default for 3D SEG-Y and (1, 16, -1) for 2D SEG-Y"
        ),
        show_default=True,
    ),
    click.option(
        "--blockshape-4d",
        type=click.Tuple([click.INT] * 4),
        default=None,
        help=(
            "Blockshape (il,xl,offset,z) for prestack (4D) SEG-Y, each at least 4. "
            "(4, 4, 4, -1) is default. Mutually exclusive with --blockshape."
        ),
        show_default=True,
    ),
    click.option(
        "--reduce-iops",
        default=False,
        type=click.BOOL,
        help=(
            "Flag to indicate whether compression should attempt to minimize "
            "the number of iops required to read the input SEG-Y file by "
            "reading whole inlines including headers in one go. "
            "Falls back to segyio if incorrect. Useful under Windows."
        ),
        show_default=True,
    ),
    click.option(
        "--get-output-size",
        default=False,
        is_flag=True,
        help=(
            "Estimate the SGZ output size in bytes without creating the output file."
        ),
        show_default=True,
    ),
]
zgy_options = [
    click.option(
        "--bits-per-voxel",
        default=4,
        type=click.INT,
        help=(
            "The number of bits to use for storing each seismic voxel. "
            "Recommended using 4-bit, giving 8:1 compression. "
            "Negative value implies reciprocal: i.e. -2 ==> 1/2 bits per voxel"
        ),
        show_default=True,
    ),
    click.option(
        "--get-output-size",
        default=False,
        is_flag=True,
        help=(
            "Estimate the SGZ output size in bytes without creating the output file."
        ),
        show_default=True,
    ),
]


def add_options(options):
    def _add_options(func):
        for option in reversed(options):
            func = option(func)
        return func

    return _add_options


@click.group()
@click.version_option(version=SeismicZfpVersion(importlib.metadata.version('seismic_zfp')).to_string())
def cli():
    """A simple command line interface for seismic-zfp."""


@cli.command("sgy2sgz", short_help="convert a SEGY file to SGZ")
@click.argument(
    "input-segy-file",
    required=True,
    type=click.Path(exists=True),
)
@click.argument(
    "output-sgz-file",
    required=False,
    type=click.Path(),
)
@add_options(sgz_options)
@add_options(segyconverter_options)
@click.version_option(version=SeismicZfpVersion(importlib.metadata.version('seismic_zfp')).to_string())
def sgy2sgz(
        input_segy_file=None,
        output_sgz_file=None,
        bits_per_voxel=None,
        blockshape=None,
        blockshape_4d=None,
        reduce_iops=None,
        get_output_size=False,
        min_il=None,
        max_il=None,
        min_xl=None,
        max_xl=None,
        min_offset=None,
        max_offset=None,
):
    if not get_output_size and output_sgz_file is None:
        raise click.UsageError("OUTPUT_SGZ_FILE is required unless using --get-output-size")
    if blockshape is not None and blockshape_4d is not None:
        raise click.UsageError("Specify only one of --blockshape and --blockshape-4d")

    with SegyConverter(
            input_segy_file,
            min_il=min_il,
            max_il=max_il,
            min_xl=min_xl,
            max_xl=max_xl,
            min_offset=min_offset,
            max_offset=max_offset,
    ) as converter:
        if converter.is_4d:
            if blockshape is not None:
                raise click.UsageError("Prestack (4D) SEG-Y requires --blockshape-4d rather than --blockshape")
            blockshape = blockshape_4d
        elif blockshape_4d is not None:
            raise click.UsageError("--blockshape-4d is only applicable to prestack (4D) SEG-Y")

        if get_output_size:
            size_bytes = converter.get_output_size(
                bits_per_voxel=bits_per_voxel,
                blockshape=blockshape,
            )
            click.echo(size_bytes)
            return

        click.echo(f"Converting {input_segy_file} to {output_sgz_file}...")
        converter.run(
            output_sgz_file,
            bits_per_voxel=bits_per_voxel,
            blockshape=blockshape,
            reduce_iops=reduce_iops,
        )


@cli.command("zgy2sgz", short_help="convert a ZGY file to SGZ")
@click.argument(
    "input-zgy-file",
    required=True,
    type=click.Path(exists=True),
)
@click.argument(
    "output-sgz-file",
    required=False,
    type=click.Path(),
)
@add_options(zgy_options)
@click.version_option(version=SeismicZfpVersion(importlib.metadata.version('seismic_zfp')).to_string())
def zgy2sgz(
        input_zgy_file=None,
        output_sgz_file=None,
        bits_per_voxel=None,
        get_output_size=False,
):
    if not get_output_size and output_sgz_file is None:
        raise click.UsageError("OUTPUT_SGZ_FILE is required unless using --get-output-size")

    with ZgyConverter(input_zgy_file) as converter:
        if get_output_size:
            size_bytes = converter.get_output_size(
                bits_per_voxel=bits_per_voxel,
            )
            click.echo(size_bytes)
            return

        click.echo(f"Converting {input_zgy_file} to {output_sgz_file}...")
        converter.run(
            output_sgz_file,
            bits_per_voxel=bits_per_voxel,
        )


@cli.command("sgz2sgy", short_help="convert a SGZ file to SEG-Y")
@click.argument(
    "input-sgz-file",
    required=True,
    type=click.Path(exists=True),
)
@click.argument(
    "output-sgy-file",
    required=True,
    type=click.Path(),
)
@click.version_option(version=SeismicZfpVersion(importlib.metadata.version('seismic_zfp')).to_string())
def sgz2sgy(
        input_sgz_file=None,
        output_sgy_file=None,
):
    click.echo(f"Converting {input_sgz_file} to {output_sgy_file}...")
    with SgzConverter(input_sgz_file) as converter:
        converter.convert_to_segy(output_sgy_file,
                                  )


if __name__ == "__main__":
    cli()
